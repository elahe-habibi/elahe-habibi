// frontend/app.js
const apiBase = 'http://localhost:3000/api';
let selectedMovie = null;
let reservationId = null;
let seatCount = null;

function showView(id) {
    document.querySelectorAll('.view').forEach(v => v.style.display = 'none');
    document.getElementById(id).style.display = '';
}

// نمایش لیست فیلم‌ها
function loadMovies() {
    fetch(apiBase + '/movies')
        .then(r => r.json())
        .then(movies => {
            const list = document.getElementById('movies-list');
            list.innerHTML = '';
            movies.forEach(m => {
                const btn = document.createElement('button');
                btn.textContent = 'رزرو';
                btn.onclick = () => {
                    selectedMovie = m;
                    showReserveForm();
                };
                const div = document.createElement('div');
                div.textContent = `${m.name} (صندلی باقیمانده: ${m.availableSeats})`;
                div.appendChild(btn);
                list.appendChild(div);
            });
        });
}

function showReserveForm() {
    document.getElementById('selected-movie').textContent = selectedMovie.name;
    document.getElementById('reserve-error').textContent = '';
    document.getElementById('seat-count').value = '';
    showView('view-reserve');
}

document.getElementById('reserve-form').onsubmit = function(e) {
    e.preventDefault();
    const seats = parseInt(document.getElementById('seat-count').value);
    seatCount = seats;
    fetch(apiBase + '/reserve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ movieId: selectedMovie.id, seats })
    })
    .then(r => r.json().then(data => ({ok: r.ok, data})))
    .then(({ok, data}) => {
        if (!ok) {
            document.getElementById('reserve-error').textContent = data.error || 'خطا در رزرو';
        } else {
            reservationId = data.reservationId;
            showUserInfoForm();
        }
    });
};

function showUserInfoForm() {
    document.getElementById('userinfo-error').textContent = '';
    document.getElementById('user-name').value = '';
    document.getElementById('user-phone').value = '';
    showView('view-userinfo');
}

document.getElementById('userinfo-form').onsubmit = function(e) {
    e.preventDefault();
    const name = document.getElementById('user-name').value;
    const phone = document.getElementById('user-phone').value;
    fetch(`${apiBase}/reserve/${reservationId}/user`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, phone })
    })
    .then(r => r.json().then(data => ({ok: r.ok, data})))
    .then(({ok, data}) => {
        if (!ok) {
            document.getElementById('userinfo-error').textContent = data.error || 'خطا در ثبت اطلاعات';
        } else {
            showPaymentView();
        }
    });
};

function showPaymentView() {
    const amount = seatCount * 100000;
    document.getElementById('payment-amount').textContent = amount;
    document.getElementById('payment-error').textContent = '';
    showView('view-payment');
}

document.getElementById('pay-btn').onclick = function() {
    const amount = seatCount * 100000;
    fetch(`${apiBase}/reserve/${reservationId}/pay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount })
    })
    .then(r => r.json().then(data => ({ok: r.ok, data})))
    .then(({ok, data}) => {
        if (!ok) {
            document.getElementById('payment-error').textContent = data.error || 'خطا در پرداخت';
        } else {
            showStatusView();
        }
    });
};

function showStatusView() {
    fetch(`${apiBase}/reserve/${reservationId}/status`)
        .then(r => r.json())
        .then(data => {
            let html = '';
            if (data.state === 'confirmed') {
                html = '<span style="color:green">رزرو شما نهایی شد</span>';
            } else if (data.state === 'pending-payment') {
                html = '<span style="color:orange">در انتظار پرداخت</span>';
            } else if (data.state === 'pending-info') {
                html = '<span style="color:orange">در انتظار ثبت اطلاعات</span>';
            } else if (data.state === 'cancelled') {
                html = '<span style="color:red">رزرو لغو شد</span>';
            } else {
                html = `<span>وضعیت: ${data.state}</span>`;
            }
            document.getElementById('status-content').innerHTML = html;
            // فقط اگر رزرو نهایی نشده باشد، دکمه لغو نمایش داده شود
            document.getElementById('cancel-btn').style.display = (data.state !== 'confirmed' && data.state !== 'cancelled') ? '' : 'none';
            showView('view-status');
        });
}

document.getElementById('cancel-btn').onclick = function() {
    fetch(`${apiBase}/reserve/${reservationId}/cancel`, {
        method: 'POST'
    })
    .then(r => r.json().then(data => ({ok: r.ok, data})))
    .then(({ok, data}) => {
        showStatusView();
    });
};

window.onload = loadMovies;
