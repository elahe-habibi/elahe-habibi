// app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = 3000;
app.use(cors());
app.use(bodyParser.json());

// State مدیریت شده در حافظه (برای هر رزرو یک State)
const movies = [
    { id: 1, name: 'Inception', availableSeats: 3 },
    { id: 2, name: 'Interstellar', availableSeats: 2 },
    { id: 3, name: 'Tenet', availableSeats: 1 },
];
const reservations = {}; // {reservationId: {movieId, seats, state, userInfo, paymentStatus}}
let reservationCounter = 1000;

// 1. دریافت لیست فیلم‌ها
app.get('/api/movies', (req, res) => {
    res.json(movies.map(({id, name, availableSeats}) => ({id, name, availableSeats})));
});

// 2. ایجاد رزرو اولیه (رزرو موقت صندلی)
app.post('/api/reserve', (req, res) => {
    const { movieId, seats } = req.body;
    const movie = movies.find(m => m.id === movieId);
    if (!movie) return res.status(404).json({error: 'Movie not found'});
    if (!Number.isInteger(seats) || seats < 1) return res.status(400).json({error: 'Invalid seat count'});
    if (movie.availableSeats < seats) return res.status(409).json({error: 'Not enough seats'});
    // کاهش موقت صندلی
    movie.availableSeats -= seats;
    const reservationId = (++reservationCounter).toString();
    reservations[reservationId] = {
        movieId,
        seats,
        state: 'pending-info', // فقط در این State قابل ادامه است
        userInfo: null,
        paymentStatus: null
    };
    res.status(201).json({ reservationId, movieId, seats, state: 'pending-info' });
});

// 3. ثبت اطلاعات کاربر برای رزرو (فقط اگر رزرو در pending-info باشد)
app.post('/api/reserve/:reservationId/user', (req, res) => {
    const { reservationId } = req.params;
    const { name, phone } = req.body;
    const reservation = reservations[reservationId];
    if (!reservation) return res.status(404).json({error: 'Reservation not found'});
    if (reservation.state !== 'pending-info') return res.status(409).json({error: 'Invalid reservation state', state: reservation.state});
    if (!name || !phone) return res.status(400).json({error: 'Missing user info'});
    reservation.userInfo = { name, phone };
    reservation.state = 'pending-payment';
    res.json({ reservationId, state: 'pending-payment' });
});

// 4. پرداخت هزینه رزرو (فقط اگر رزرو در pending-payment باشد)
app.post('/api/reserve/:reservationId/pay', (req, res) => {
    const { reservationId } = req.params;
    const { amount } = req.body;
    const reservation = reservations[reservationId];
    if (!reservation) return res.status(404).json({error: 'Reservation not found'});
    if (reservation.state !== 'pending-payment') return res.status(409).json({error: 'Invalid reservation state', state: reservation.state});
    // فرض: قیمت هر صندلی 100 هزار تومان
    const expected = reservation.seats * 100000;
    if (amount !== expected) return res.status(400).json({error: 'Incorrect payment amount', expected});
    reservation.state = 'confirmed';
    reservation.paymentStatus = 'paid';
    res.json({ reservationId, state: 'confirmed' });
});

// 5. دریافت وضعیت رزرو
app.get('/api/reserve/:reservationId/status', (req, res) => {
    const { reservationId } = req.params;
    const reservation = reservations[reservationId];
    if (!reservation) return res.status(404).json({error: 'Reservation not found'});
    res.json({ reservationId, state: reservation.state, paymentStatus: reservation.paymentStatus });
});

// 6. کنسل کردن رزرو (فقط اگر رزرو هنوز Confirm نشده)
app.post('/api/reserve/:reservationId/cancel', (req, res) => {
    const { reservationId } = req.params;
    const reservation = reservations[reservationId];
    if (!reservation) return res.status(404).json({error: 'Reservation not found'});
    if (reservation.state === 'confirmed') return res.status(409).json({error: 'Cannot cancel confirmed reservation'});
    // بازگرداندن صندلی‌ها
    const movie = movies.find(m => m.id === reservation.movieId);
    if (movie) movie.availableSeats += reservation.seats;
    reservation.state = 'cancelled';
    res.json({ reservationId, state: 'cancelled' });
});

app.listen(port, () => {
    console.log(`Cinema API running on http://localhost:${port}`);
});
