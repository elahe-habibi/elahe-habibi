// app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');
const app = express();
app.use(cors());
app.use(bodyParser.json());

// حافظه سبدهای خرید و سفارشات
const carts = {};
const orders = {};

function generateId() {
  return crypto.randomBytes(8).toString('hex');
}

// ایجاد سبد خرید جدید
app.post('/cart', (req, res) => {
  const cartId = generateId();
  carts[cartId] = { items: [], status: 'active', lastAction: Date.now() };
  res.status(201).json({ cartId });
});

// افزودن آیتم به سبد (باید سبد فعال باشد)
app.post('/cart/:cartId/item', (req, res) => {
  const { cartId } = req.params;
  const { productId, quantity } = req.body;
  if (!carts[cartId]) return res.status(404).json({ error: 'Cart not found' });
  if (carts[cartId].status !== 'active') return res.status(409).json({ error: 'Cart is not active' });
  if (!productId || !quantity || quantity < 1) return res.status(400).json({ error: 'Invalid product/quantity' });
  const existing = carts[cartId].items.find(i => i.productId === productId);
  if (existing) existing.quantity += quantity;
  else carts[cartId].items.push({ productId, quantity });
  carts[cartId].lastAction = Date.now();
  res.json({ items: carts[cartId].items });
});

// حذف آیتم از سبد
app.delete('/cart/:cartId/item/:productId', (req, res) => {
  const { cartId, productId } = req.params;
  if (!carts[cartId]) return res.status(404).json({ error: 'Cart not found' });
  if (carts[cartId].status !== 'active') return res.status(409).json({ error: 'Cart is not active' });
  const index = carts[cartId].items.findIndex(i => i.productId === productId);
  if (index === -1) return res.status(404).json({ error: 'Product not in cart' });
  carts[cartId].items.splice(index, 1);
  carts[cartId].lastAction = Date.now();
  res.json({ items: carts[cartId].items });
});

// مشاهده سبد خرید
app.get('/cart/:cartId', (req, res) => {
  const { cartId } = req.params;
  if (!carts[cartId]) return res.status(404).json({ error: 'Cart not found' });
  res.json({ items: carts[cartId].items, status: carts[cartId].status });
});

// ثبت سفارش (سبد باید حداقل یک آیتم داشته و فعال باشد)
app.post('/cart/:cartId/checkout', (req, res) => {
  const { cartId } = req.params;
  if (!carts[cartId]) return res.status(404).json({ error: 'Cart not found' });
  if (carts[cartId].status !== 'active') return res.status(409).json({ error: 'Cart is not active' });
  if (carts[cartId].items.length === 0) return res.status(400).json({ error: 'Cart is empty' });
  carts[cartId].status = 'checkedout';
  const orderId = generateId();
  orders[orderId] = { cartId, items: [...carts[cartId].items], created: Date.now() };
  res.status(201).json({ orderId });
});

// مشاهده سفارش
app.get('/order/:orderId', (req, res) => {
  const { orderId } = req.params;
  if (!orders[orderId]) return res.status(404).json({ error: 'Order not found' });
  res.json({ ...orders[orderId] });
});

// سبدهای خرید پس از 5 دقیقه عدم فعالیت غیرفعال می‌شوند
setInterval(() => {
  const now = Date.now();
  Object.entries(carts).forEach(([cartId, cart]) => {
    if (cart.status === 'active' && now - cart.lastAction > 5 * 60 * 1000) {
      cart.status = 'expired';
    }
  });
}, 60 * 1000);

app.listen(3000, () => {
  console.log('Shopping Cart API running on port 3000');
});
