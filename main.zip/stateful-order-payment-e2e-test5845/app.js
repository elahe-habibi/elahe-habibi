// app.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(bodyParser.json());
app.use(cors());

// State storage
const orders = {};
const products = {
  'P001': { name: 'کتاب', price: 120000 },
  'P002': { name: 'ماگ', price: 70000 },
  'P003': { name: 'کوله', price: 250000 }
};

const orderStates = ['CREATED', 'FILLED', 'PAID', 'CANCELLED'];

function newOrderId() {
  return crypto.randomBytes(4).toString('hex');
}

// Create Order
app.post('/api/orders', (req, res) => {
  const orderId = newOrderId();
  orders[orderId] = {
    id: orderId,
    state: 'CREATED',
    items: [],
    total: 0
  };
  res.status(201).json({ orderId, state: 'CREATED' });
});

// Add Item
app.post('/api/orders/:orderId/items', (req, res) => {
  const { orderId } = req.params;
  const { productId, quantity } = req.body;
  const order = orders[orderId];
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (order.state !== 'CREATED') return res.status(409).json({ error: 'Cannot add item at this state', state: order.state });
  if (!products[productId]) return res.status(400).json({ error: 'Invalid product' });
  if (!quantity || quantity < 1) return res.status(400).json({ error: 'Invalid quantity' });
  order.items.push({ productId, quantity });
  order.total += products[productId].price * quantity;
  res.status(200).json({ orderId, items: order.items, total: order.total });
});

// Submit Order (Fill)
app.post('/api/orders/:orderId/submit', (req, res) => {
  const { orderId } = req.params;
  const order = orders[orderId];
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (order.state !== 'CREATED') return res.status(409).json({ error: 'Order cannot be submitted at this state', state: order.state });
  if (order.items.length === 0) return res.status(400).json({ error: 'Order is empty' });
  order.state = 'FILLED';
  res.status(200).json({ orderId, state: order.state, total: order.total });
});

// Pay Order
app.post('/api/orders/:orderId/pay', (req, res) => {
  const { orderId } = req.params;
  const { paymentCode } = req.body;
  const order = orders[orderId];
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (order.state !== 'FILLED') return res.status(409).json({ error: 'Order not ready for payment', state: order.state });
  if (!paymentCode || paymentCode.length < 5) return res.status(400).json({ error: 'Invalid payment code' });
  // simulate payment failure for special code
  if (paymentCode === 'FAIL1') {
    return res.status(402).json({ error: 'Payment declined' });
  }
  order.state = 'PAID';
  res.status(200).json({ orderId, state: order.state });
});

// Cancel Order
app.post('/api/orders/:orderId/cancel', (req, res) => {
  const { orderId } = req.params;
  const order = orders[orderId];
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (order.state === 'PAID') return res.status(409).json({ error: 'Cannot cancel a paid order' });
  if (order.state === 'CANCELLED') return res.status(409).json({ error: 'Order already cancelled' });
  order.state = 'CANCELLED';
  res.status(200).json({ orderId, state: order.state });
});

// Get Order
app.get('/api/orders/:orderId', (req, res) => {
  const { orderId } = req.params;
  const order = orders[orderId];
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.status(200).json(order);
});

// List Products
app.get('/api/products', (req, res) => {
  res.status(200).json(Object.keys(products).map(id => ({ id, ...products[id] })));
});

app.listen(3000, () => {
  console.log('API server running on port 3000');
});
