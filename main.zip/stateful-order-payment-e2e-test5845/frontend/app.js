// frontend/app.js
const API_BASE = 'http://localhost:3000/api';
let currentOrderId = null;
let currentOrder = null;

function showView(viewId) {
  document.querySelectorAll('.view').forEach(v => v.style.display = 'none');
  document.getElementById(viewId).style.display = '';
}

async function fetchProducts() {
  const res = await fetch(`${API_BASE}/products`);
  return res.json();
}

async function createOrder() {
  const res = await fetch(`${API_BASE}/orders`, { method: 'POST' });
  return res.json();
}

async function addItem(orderId, productId, quantity) {
  const res = await fetch(`${API_BASE}/orders/${orderId}/items`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ productId, quantity })
  });
  return res.json().then(data => ({ status: res.status, ...data }));
}

async function submitOrder(orderId) {
  const res = await fetch(`${API_BASE}/orders/${orderId}/submit`, { method: 'POST' });
  return res.json().then(data => ({ status: res.status, ...data }));
}

async function payOrder(orderId, paymentCode) {
  const res = await fetch(`${API_BASE}/orders/${orderId}/pay`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ paymentCode })
  });
  return res.json().then(data => ({ status: res.status, ...data }));
}

async function cancelOrder(orderId) {
  const res = await fetch(`${API_BASE}/orders/${orderId}/cancel`, { method: 'POST' });
  return res.json().then(data => ({ status: res.status, ...data }));
}

function renderOrderItems(items, products) {
  if (!items || !items.length) return '<em>سبد خالی است</em>';
  return '<ul>' + items.map(item => `<li>${products[item.productId].name} x ${item.quantity}</li>`).join('') + '</ul>';
}

async function setupOrderView() {
  const products = await fetchProducts();
  const productSelect = document.getElementById('product-select');
  productSelect.innerHTML = '';
  products.forEach(p => {
    const option = document.createElement('option');
    option.value = p.id;
    option.textContent = `${p.name} (${p.price} تومان)`;
    productSelect.appendChild(option);
  });

  const orderData = await createOrder();
  currentOrderId = orderData.orderId;
  currentOrder = { items: [], total: 0 };
  document.getElementById('order-items').innerHTML = renderOrderItems([], products.reduce((acc, p) => (acc[p.id]=p,acc), {}));
  document.getElementById('order-error').textContent = '';

  document.getElementById('add-item-btn').onclick = async function() {
    const pid = productSelect.value;
    const qty = parseInt(document.getElementById('quantity-input').value, 10);
    const result = await addItem(currentOrderId, pid, qty);
    if (result.status !== 200) {
      document.getElementById('order-error').textContent = result.error || 'خطا در افزودن کالا';
      return;
    }
    currentOrder.items = result.items;
    currentOrder.total = result.total;
    document.getElementById('order-items').innerHTML = renderOrderItems(result.items, products.reduce((acc, p) => (acc[p.id]=p,acc), {}));
    document.getElementById('order-error').textContent = '';
  };

  document.getElementById('create-order-form').onsubmit = async function(e) {
    e.preventDefault();
    const result = await submitOrder(currentOrderId);
    if (result.status !== 200) {
      document.getElementById('order-error').textContent = result.error || 'خطا در ثبت سفارش';
      return;
    }
    setupPaymentView();
  };
}

async function setupPaymentView() {
  showView('view-payment');
  document.getElementById('payment-summary').textContent = `مبلغ کل: ${currentOrder.total} تومان`;
  document.getElementById('payment-error').textContent = '';
  document.getElementById('payment-code-input').value = '';

  document.getElementById('payment-form').onsubmit = async function(e) {
    e.preventDefault();
    const code = document.getElementById('payment-code-input').value.trim();
    const result = await payOrder(currentOrderId, code);
    if (result.status === 200) {
      showResult('پرداخت موفق', 'سفارش شما با موفقیت پرداخت شد.');
    } else {
      document.getElementById('payment-error').textContent = result.error || 'خطا در پرداخت';
    }
  };

  document.getElementById('cancel-order-btn').onclick = async function() {
    const result = await cancelOrder(currentOrderId);
    if (result.status === 200) {
      showResult('لغو شد', 'سفارش شما لغو گردید.');
    } else {
      document.getElementById('payment-error').textContent = result.error || 'خطا در لغو سفارش';
    }
  };
}

function showResult(title, msg) {
  showView('view-result');
  document.getElementById('result-title').textContent = title;
  document.getElementById('result-message').textContent = msg;
}

document.getElementById('new-order-btn').onclick = function() {
  showView('view-order');
  setupOrderView();
};

// Initialize
showView('view-order');
setupOrderView();
